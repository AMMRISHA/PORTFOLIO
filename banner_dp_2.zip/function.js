
function myFunction() {
  alert("Thanks for your Interest!!");
}

